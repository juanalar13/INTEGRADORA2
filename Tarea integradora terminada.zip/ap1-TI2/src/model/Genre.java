package model;

public enum Genre {
	
	unknown, Rock, HipHop, Clasica, Reggae, Salsa, Metal;
	
}
