package model;

public enum Category {
	newbie, littleContributor, mildContributor, starContributor; 
}
