package model;

import java.util.Date;

public class Song {
	private String title;
	private String artist;
	private Date date;
	private String duration;
	private int mins;
	private int secs;
	private Genre genre;
	
	public Song(String title, String artist, Date date, int mins, int secs, Genre genre) {
		this.title = title;
		this.artist = artist;
		this.date = date;
		this.mins = mins;
		this.secs = secs;
		setDuration(mins, secs);;
		this.genre = genre;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(int mins, int secs) {
		int minsT = mins;
		int secsT = secs;
		
		if (secsT > 60) {
			minsT++;
			secsT = secsT - 60;
		}
		
		setMins(minsT);
		setSecs(secsT);
		
		this.duration = ""+minsT+":"+secsT;
	}

	public int getMins() {
		return mins;
	}

	public void setMins(int mins) {
		this.mins = mins;
	}

	public int getSecs() {
		return secs;
	}

	public void setSecs(int secs) {
		this.secs = secs;
	}

	public Genre getGenre() {
		return genre;
	}

	public void setGenre(Genre genre) {
		this.genre = genre;
	}
	
	public String toString() {
		return "\n**************  Song **************"+
				"\n**  Title: "+title+
				"\n**  Artist: "+artist+
				"\n**  Duration: "+duration+
				"\n**  Genre: "+genre+ 
				"\n***********************************";
	}
}
