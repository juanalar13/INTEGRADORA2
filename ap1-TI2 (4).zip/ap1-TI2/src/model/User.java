package model;

public class User {
	private String userName;
	private String password;
	private int age;
	private Category category;
	private int contribution;
	
	public User(String userName, String password, int age, Category category) {
		this.userName = userName;
		this.password = password;
		this.age = age;
		this.category = category;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}
	
	public int getContribution() {
		return contribution;
	}
	
	public void setContribution(int contribution) {
		this.contribution = contribution;
		updateCategory();
	}
	
	public void updateCategory() {
		switch (contribution) {
		case 3:
			category = Category.littleContributor;
			break;
			
		case 10:
			category = Category.mildContributor;
			break;
			
		case 30:
			category = Category.starContributor;
		}
	}
	
	public String toString() {
		return "*************  User **************"+
				"\n**  UserName: "+userName+
				"\n**  Age: "+age+
				"\n**  Category: "+category+
				"\n***********************************";

	}
}
