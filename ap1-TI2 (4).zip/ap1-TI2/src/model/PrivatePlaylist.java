package model;

public class PrivatePlaylist extends Playlist{
	
	private User uniqueUser;

	public PrivatePlaylist(String name, int mins, int secs, User uniqueUser) {
		super(name, mins, secs);
		this.uniqueUser = uniqueUser;
		privatePlaylist = true;
	}

	public User getUniqueUser() {
		return uniqueUser;
	}

	public void setUniqueUser(User uniqueUser) {
		this.uniqueUser = uniqueUser;
	}
	
	public String toSting(){
		return super.toString()+
				"\n**  User: "+uniqueUser.getUserName()+
				"\n***************************************";
	}

}
