package model;

public class RestrictedPlaylist extends Playlist{
	
	private User[] users;
	public final static int SIZE_OF_USERS = 5;

	public RestrictedPlaylist(String name, int mins, int secs, User[] users) {
		super(name, mins, secs);
		this.users = new User[SIZE_OF_USERS];
		this.users = users;
	}

	public String getUsers() {
		String names = "";
		
		for (int i = 0; i < users.length; i++) {
			if (users[i] != null) {
				names += users[i].getUserName()+", ";
			}
		}
		
		return names;
	}

	public void setUsers(User[] users) {
		this.users = users;
	}

	public String toSting(){
		return super.toString()+
				"\n**  Users: "+getUsers().substring(0, getUsers().length()-2)+
				"\n***************************************";
	}
}
