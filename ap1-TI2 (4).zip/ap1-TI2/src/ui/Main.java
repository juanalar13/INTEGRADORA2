package ui;

import java.util.Scanner;

import model.App;
import model.Genre;

public class Main {
	private App controller;
	Scanner reader;

	public static void main(String[] args) {
		Main m = new Main();
	}
	
	public Main() {
		System.out.println(showBanner());
		reader = new Scanner(System.in);
		controller = new App();
		boolean exit = false;
		
		do {
			showMenu();
			int option = reader.nextInt();
			reader.nextLine();
			
			switch (option) {
			case 1:
				createUser();
				break;
				
			case 2:
				showUsers();
				break;
				
			case 3:
				createSong();
				break;

			case 4:
				showSongs();
				break;

			case 5:
				createPlaylist();
				break;
				
			case 6:
				addSongToPlaylist();
				break;
				
			case 7:
				rateAPlaylist();
				break;

			case 8:
				showPlaylist();
				break;

			case 9:
				
				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
				System.out.println("~~~~~~~~~~~~~ THANKS FOR USE OUR APP ~~~~~~~~~~~~~");
				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
				exit = true;
				
				break;

			default:
				System.out.println("INCORRECT OPTION. PLEASE SELECT A VALID OPTION");
				break;
			}
		} while (!exit);
		
	}
	
	public String showBanner() {
		return "(((((((((((((((((((((((((((((((((((((((((((((((((\r\n" + 
				"((((((((((((((((/((((((((((((((((((((((((((((((((\r\n" + 
				"(((/  .(((((((*  .((((((*        (((((/      /(((\r\n" + 
				"(((/   .((((((.  .(((((   ,((((((((((*  .((((((((\r\n" + 
				"(((/    /((((/   .((((/  ,(((((((((((.  /((((((((\r\n" + 
				"(((/     ((((*   .((((*  ,(((((((((((/   ((((((((\r\n" + 
				"(((/  *  *(((     ((((*  ,((((((((((((,  .(((((((\r\n" + 
				"(((/  /.  ((*     ((((*  *(((((((((((((,   ((((((\r\n" + 
				"(((/  //  ,(  .   ((((*  *((((((((((((((/   /((((\r\n" + 
				"(((/  *(*  ,  (   ((((*  *((((((((((((((((   /(((\r\n" + 
				"(((/  ,(/    ,(   /(((*  ,(((((((((((((((((   (((\r\n" + 
				"(((/  .((    ((   /((((  .(((((((((((((((((.  /((\r\n" + 
				"(((/  .((.  .((.  *((((,  *((((((((((((((((   /((\r\n" + 
				"(((/  .((((((((.  *(((((   *((((/,/(((((((/   (((\r\n" + 
				"(((/  .((((((((.  *((((((.        *((   .   .((((\r\n" + 
				"(((((((((((((((/*/((((((((((///(((((((////(((((((\r\n" + 
				"(((((((((((((((((((((((((((((((((((((((((((((((((\r\n" + 
				"               ./(###((///((###(*                \r\n" + 
				"           *#(,                   *((,           \r\n" + 
				"        ,#/                           ((         \r\n" + 
				"      .#*          .**/////*,.          ((       \r\n" + 
				"     *(.      .//////////////////*       *#      \r\n" + 
				"    .#,     *///////////////////////,     /(     \r\n" + 
				"    /(    *///////////////////////////    .#.    \r\n" + 
				"  ,/////,*/////////////////////////////,*////*.  \r\n" + 
				"  /////////////////////////*,...,/////////////,  \r\n" + 
				"  //////*,,,********,,.............,,,,,//////,  \r\n" + 
				"  //////*.........//*........//*.......,//////,  \r\n" + 
				"  //////*.........,,.........,,........,//////,  \r\n" + 
				"  //////*..............................,//////,  \r\n" + 
				"   *///*  ........,/.........**.......  .*///,   \r\n" + 
				"            .......,/*.....,/*.......            \r\n" + 
				"               ........,,,,.......               \r\n" + 
				"                    .........                    \r\n" + 
				"     \r\n" + 
				"*************************************************\r\n";
	}
	
	public void showMenu() {
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("+++++ Welcome. Please select an option. ++++++");
		System.out.println("1. Create new user.");
		System.out.println("2. Show users on list.");
		System.out.println("3. Create and share a new song.");
		System.out.println("4. Show songs on pool.");
		System.out.println("5. Create new playlist.");
		System.out.println("6. Add a song to a playlist.");
		System.out.println("7. Rate a public playlist.");
		System.out.println("8. Show playlist on list.");
		System.out.println("9. Exit.");
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
	}
	
	public void createUser() {
		System.out.println("Please enter your username:");
		String username = reader.nextLine();
		System.out.println("Please enter your password:");
		String password = reader.nextLine();
		System.out.println("Please enter your age:");
		int age = reader.nextInt();
		reader.nextLine();
		
		System.out.println(controller.addUser(username, password, age));
	}
	
	public void showUsers() {
		System.out.println(controller.showUsers());
	}
	
	public void createSong() {
		System.out.println("Please enter the username of the contributor:");
		String userName = reader.nextLine();
		System.out.println("Please enter the title of the song:");
		String title = reader.nextLine();
		System.out.println("Please enter the artist of the song:");
		String artist = reader.nextLine();
		System.out.println("Please entrer the day of launch of the song:");
		int day = reader.nextInt();
		reader.nextLine();
		System.out.println("Please entrer the month of launch of the song:");
		int month = reader.nextInt();
		reader.nextLine();
		System.out.println("Please entrer the year of launch of the song:");
		int year = reader.nextInt();
		reader.nextLine();
		System.out.println("Please enter the minutes of duration of the song");
		int mins = reader.nextInt();
		reader.nextLine();
		System.out.println("Please entrer the seconds of duration of the song:");
		int secs = reader.nextInt();
		reader.nextLine();
		showGenres();
		int genreNum = reader.nextInt();
		reader.nextLine();
		Genre genre = Genre.unknown;
		switch (genreNum) {
		case 1:
			genre = Genre.Rock;
			break;
			
		case 2:
			genre = Genre.HipHop;
			break;
			
		case 3:
			genre = Genre.Clasica;
			break;
			
		case 4:
			genre = Genre.Reggae;
			break;
			
		case 5:
			genre = Genre.Salsa;
			break;
			
		case 6:
			genre = Genre.Metal;
			break;
			
		default:
			System.out.println("ERROR. INCORRECT OPTION. PLEASE SELECT A VALID OPTION");
			break;
		}
		
		if (!genre.equals(Genre.unknown)) {
			System.out.println(controller.addSong(userName, title, artist, day, month, year, mins, secs, genre));
		}
	}
	
	public void showGenres() {
		System.out.println("Please choose for the song one of the followings genres:");
		System.out.println("1. Rock");
		System.out.println("2. HipHop");
		System.out.println("3. Clasica");
		System.out.println("4. Reggae");
		System.out.println("5. Salsa");
		System.out.println("6. Metal");
	}
	
	public void showSongs() {
		System.out.println(controller.showSongs());
	}

	public void createPlaylist() {
		System.out.println("Please choose which type of playlist do you wanna create:");
		System.out.println("1. Public");
		System.out.println("2. Private");
		System.out.println("3. Restricted");
		
		int type = reader.nextInt();
		reader.nextLine();
		
		switch (type) {
		case 1:
			createPublicPlaylist();
			break;
			
		case 2:
			createPrivatePlaylist();
			break;
			
		case 3:
			createRestrictedPlaylist();
			break;

		default:
			System.out.println("ERROR. INCORRECT OPTION. PLEASE SELECT A VALID OPTION");
			break;
		}
	}
	
	public void createPublicPlaylist() {
		System.out.println("Please enter the name of the playlist to create");
		String name = reader.nextLine();
		System.out.println(controller.addPublicPlaylist(name, 0, 0));
	}
	
	public void createPrivatePlaylist() {
		System.out.println("Please enter the name of the playlist to create");
		String name = reader.nextLine();
		System.out.println("Please enter the username of the unique user of the playlist:");
		String userName = reader.nextLine();
		
		System.out.println(controller.addPrivatePlaylist(name, 0, 0, userName));
	}
	
	public void createRestrictedPlaylist() {
		System.out.println("Please enter the name of the playlist to create");
		String name = reader.nextLine();
		System.out.println("Please enter the username of the first user of the playlist: (OBLIGATORY)");
		String userName = reader.nextLine();
		System.out.println("Please enter the username of the second user of the playlist: (CAN LEAVE IT EMPTY)");
		String userName2 = reader.nextLine();
		System.out.println("Please enter the username of the third user of the playlist: (CAN LEAVE IT EMPTY)");
		String userName3 = reader.nextLine();
		System.out.println("Please enter the username of the fourth user of the playlist: (CAN LEAVE IT EMPTY)");
		String userName4 = reader.nextLine();
		System.out.println("Please enter the username of the fifth user of the playlist: (CAN LEAVE IT EMPTY)");
		String userName5 = reader.nextLine();
		
		System.out.println(controller.addRestrictedPlaylist(name, 0, 0, userName, userName2, userName3, userName4, userName5));
	}
	
	public void addSongToPlaylist() {
		System.out.println("Please enter the title of the song:");
		String title = reader.nextLine();
		System.out.println("Please enter the name of the artist:");
		String artist = reader.nextLine();
		System.out.println("Please enter the name of the playlist:");
		String playlistName = reader.nextLine();
		
		System.out.println(controller.addSongToPlaylist(title, artist, playlistName));
	}
	
	public void rateAPlaylist() {
		System.out.println("Please enter the name of the playlist:");
		String playlistName = reader.nextLine();
		System.out.println("Please enter the grade: (1-5)");
		int grade = reader.nextInt();
		reader.nextLine();
		
		System.out.println(controller.addGradeToPublicPlaylist(playlistName, grade));
	}
	
	public void showPlaylist() {
		System.out.println(controller.showPlaylists());
	}
}
