package model;

public enum Genre {
	
	rock, hipHop, clasica, reggae, salsa, metal;
	
}
