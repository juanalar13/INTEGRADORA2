package model;

public class PublicPlaylist extends Playlist{
	private int grade;

	public PublicPlaylist(String name, int mins, int secs) {
		super(name, mins, secs);
	}
	
	public int getGrade() {
		return grade;
	}

	public boolean setGrade(int grade) {
		boolean added = false;
		if (grade <= 5 && grade >= 1) {
			this.grade = grade;
			added = true;
		}
		
		return added;
	}

	public String toSting(){
		return super.toString()+
				"\n**  Grade: "+grade+
				"\n***************************************";
	}
	
}
