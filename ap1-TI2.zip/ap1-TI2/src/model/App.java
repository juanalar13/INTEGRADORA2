package model;

public class App {
	private User[] users;
	private Song[] poolOfSongs;
	private Playlist[] playlists;
	
	public static final int SIZE_OF_USERS = 10;
	public static final int AMOUNT_OF_SONGS = 30;
	public static final int AMOUNT_OF_PLAYLISTS = 20;
	
	public App() {
		users = new User[SIZE_OF_USERS];
		poolOfSongs = new Song[AMOUNT_OF_SONGS];
		playlists = new Playlist[AMOUNT_OF_PLAYLISTS];
	}
	
	public User findUser(String userName) {
		User toFind = null;
		boolean found = false;
		
		for (int i = 0; i < users.length && !found; i++) {
			if (users[i].getUserName().equalsIgnoreCase(userName)) {
				toFind = users[i];
				found = true;
			}
		}
		
		return toFind;
	}
	
	public String addUser(String userName, String password, int age) {
		String msg = "";
		
		if (!userName.contains(" ") && findUser(userName) == null) {
			msg = "ERROR: IT WAS NOT POSSIBLE TO ADD THE USER. THE LIST OF USERS IS FULL";
			boolean added = false;
			User us = new User(userName, password, age, "Newbie");
			
			for (int i = 0; i < users.length && !added; i++) {
				if (users[i] == null) {
					users[i] = us;
					added = true;
					msg = "USER ADDED SUCCESFULLY";
				}
			}
		}else {
			msg = "ERROR: IT WAS NOT POSSIBLE TO ADD THE USER. \n THIS USERNAME IS ALREADY IN USE OR HAVE SPACES ON IT";
		}
		
		return msg;
	}
	
	public String showUsers() {
		String info = "";
		
		for (int i = 0; i < users.length; i++) {
			if(users[i] != null) {
				info += users[i]+"\n";
			}
		}
		
		if (info.equals("")) {
			info = "THERE IS NO USERS ADDED TO THE LIST";
		}
		
		return info;
	}
	
	public String addSong(String userName, String title, String artist, String date, int mins, int secs, String genre) {
		String msg = "";
		
		
		
		return msg;
	}
}
