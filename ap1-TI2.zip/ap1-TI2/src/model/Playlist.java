package model;

public class Playlist {
	public String name;
	public String duration;
	private int mins;
	private int secs;
	public String genre;
	public Song[] songs;
	public static final int AMOUNT_OF_SONGS = 30;
	
	public Playlist(String name, int mins, int secs) {
		this.name = name;
		this.mins = mins;
		this.secs = secs;
		songs = new Song[AMOUNT_OF_SONGS];
		setGenre();
		duration = ""+mins+":"+secs;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		String[] durationA = duration.split(":");
		int minsN = Integer.parseInt(durationA[0]);
		int secsN = Integer.parseInt(durationA[1]);
		int minsO = mins;
		int secsO = secs;
		
		int minsT = minsN + minsO;
		int secsT = secsN + secsO;
		
		if (secsT > 60) {
			minsT++;
			secsT = secsT - 60;
		}
		
		setMins(minsT);
		setSecs(secsT);
		
		this.duration = ""+minsT+":"+secsT;
	}

	public int getMins() {
		return mins;
	}

	public void setMins(int mins) {
		this.mins = mins;
	}

	public int getSecs() {
		return secs;
	}

	public void setSecs(int secs) {
		this.secs = secs;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre() {
		String sGenre = "";
		for (int i = 0; i < songs.length; i++) {
			sGenre += songs[i].getGenre()+", ";
		}
		genre = sGenre;
	}

	public Song[] getSongs() {
		return songs;
	}

	public void setSongs(Song[] songs) {
		this.songs = songs;
	}
	
	public boolean addSong(Song toAdd) {
		boolean added = false;
		
		for (int i = 0; i < songs.length && !added; i++) {
			if (songs[i] == null) {
				songs[i] = toAdd;
				added = true;
				setGenre();
			}
		}
		
		return added;
	}
	
	public String toString() {
		return "**************  Playlist **************\n"+
				"**  Title: "+name+
				"\n**  Duration: "+duration+
				"\n**  Genre: "+genre.substring(0, genre.length()-2);
	}
}
