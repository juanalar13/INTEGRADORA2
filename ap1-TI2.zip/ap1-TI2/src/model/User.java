package model;

public class User {
	private String userName;
	private String password;
	private int age;
	private String category;
	
	public User(String userName, String password, int age, String category) {
		this.userName = userName;
		this.password = password;
		this.age = age;
		this.category = category;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	public String toString() {
		return "*************  User **************"+
				"\n**  UserName: "+userName+
				"\n**  Age: "+age+
				"\n**  Category: "+category+
				"\n***********************************";

	}
}
